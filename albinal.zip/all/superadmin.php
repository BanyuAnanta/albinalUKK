<?php
session_start();
include('koneksi.php');

if(isset($_POST['tambah'])){
    $username = $_POST['username'];
    $password = $_POST['password'];
    $role = $_POST['role'];

    mysqli_query($koneksi, "INSERT INTO user (username, password, role)
                            VALUES ('$username', '$password', '$role')");
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>SUPERADMIN - Tambah Pengguna</title>
    <style>
  
    </style>
</head>
<body>
    <form action="superadmin.php" method="post">
        <h2>Tambah Pengguna Baru</h2>
        <input type="text" name="username" placeholder="Username" required><br>
        <input type="password" name="password" placeholder="Password" required><br>
        <select name="role" required>
            <option value="">Pilih Role</option>
            <option value="user">User</option>
            <option value="admin">Admin</option>
            <option value="superadmin">Superadmin</option>
        </select><br>
        <input type="submit" name="tambah" value="TAMBAH PENGGUNA">
    </form>
</body>
</html>