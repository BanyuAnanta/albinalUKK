<?php
session_start();
include('koneksi.php'); 
if (!$koneksi) {
    die("Connection failed: " . mysqli_connect_error());
}

$data = []; 


if(isset($_GET['id'])){
    $no_buku_to_edit = mysqli_real_escape_string($koneksi, $_GET['id']);
    $sql_fetch = "SELECT * FROM buku WHERE no_buku = '$no_buku_to_edit'";
    $result_fetch = mysqli_query($koneksi, $sql_fetch);

    if($result_fetch && mysqli_num_rows($result_fetch) > 0){
        $data = mysqli_fetch_assoc($result_fetch);
    } else {
        echo "<p style='color: red; text-align: center;'>Buku tidak ditemukan atau terjadi kesalahan.</p>";
        ;
    }
}


if(isset($_POST['edit'])){
    $no_buku        = mysqli_real_escape_string($koneksi, $_POST['no_buku']);
    $kode_buku      = mysqli_real_escape_string($koneksi, $_POST['kode_buku']);
    $judul_buku     = mysqli_real_escape_string($koneksi, $_POST['judul_buku']);
    $tahun_terbit   = mysqli_real_escape_string($koneksi, $_POST['tahun_terbit']);
    $nama_penulis   = mysqli_real_escape_string($koneksi, $_POST['nama_penulis']);
    $penerbit       = mysqli_real_escape_string($koneksi, $_POST['penerbit']);
    $jumlah_halaman = mysqli_real_escape_string($koneksi, $_POST['jumlah_halaman']);
    $harga          = mysqli_real_escape_string($koneksi, $_POST['harga']);
    $gambar_buku    = mysqli_real_escape_string($koneksi, $_POST['gambar_buku']);

    $sql_update = "UPDATE buku SET
                    kode_buku = '$kode_buku',
                    judul_buku = '$judul_buku',
                    tahun_terbit = '$tahun_terbit',
                    nama_penulis = '$nama_penulis',
                    penerbit = '$penerbit',
                    jumlah_halaman = '$jumlah_halaman',
                    harga = '$harga',
                    gambar_buku = '$gambar_buku'
                   WHERE no_buku = '$no_buku'";

    if(mysqli_query($koneksi, $sql_update)){
        echo "<p style='color: green; text-align: center;'>Data buku berhasil diperbarui!</p>";
        
        header("Location: admin.php");
        exit();
    } else {
        echo "<p style='color: red; text-align: center;'>Error memperbarui data: " . mysqli_error($koneksi) . "</p>";
    }
}


mysqli_close($koneksi);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Buku</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            margin: 0;
            color: #333;
            display: flex;
            justify-content: center; 
            align-items: center; 
            min-height: 100vh; 
        }
        form {
            background-color: #fff;
            padding: 25px;
            border-radius: 8px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            max-width: 500px; 
            width: 100%;
            box-sizing: border-box;
        }
        h2 {
            color: #0056b3;
            text-align: center;
            margin-bottom: 25px;
            font-size: 1.8em;
        }
        input[type="text"],
        input[type="number"] {
            width: 100%;
            padding: 12px;
            margin-bottom: 15px;
            border: 1px solid #ccc;
            border-radius: 5px;
            box-sizing: border-box;
            font-size: 16px;
        }
        input[type="submit"] {
            background-color: #007bff; 
            color: white;
            padding: 12px 20px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            font-size: 17px;
            font-weight: bold;
            width: 100%;
            transition: background-color 0.3s ease;
        }
        input[type="submit"]:hover {
            background-color: #0056b3;
        }
    </style>
</head>
<body>
    <form action="" method="post">
        <h2>Edit Detail Buku</h2>
        <input type="hidden" name="no_buku" value="<?php echo htmlspecialchars($data['no_buku'] ?? ''); ?>">

        <input type="text" name="kode_buku" value="<?php echo htmlspecialchars($data['kode_buku'] ?? ''); ?>" placeholder="Kode Buku" required><br>
        <input type="text" name="judul_buku" value="<?php echo htmlspecialchars($data['judul_buku'] ?? ''); ?>" placeholder="Judul Buku" required><br>
        <input type="text" name="tahun_terbit" value="<?php echo htmlspecialchars($data['tahun_terbit'] ?? ''); ?>" placeholder="Tahun Terbit" required><br>
        <input type="text" name="nama_penulis" value="<?php echo htmlspecialchars($data['nama_penulis'] ?? ''); ?>" placeholder="Nama Penulis" required><br>
        <input type="text" name="penerbit" value="<?php echo htmlspecialchars($data['penerbit'] ?? ''); ?>" placeholder="Penerbit" required><br>
        <input type="number" name="jumlah_halaman" value="<?php echo htmlspecialchars($data['jumlah_halaman'] ?? ''); ?>" placeholder="Jumlah Halaman" required><br>
        <input type="number" name="harga" value="<?php echo htmlspecialchars($data['harga'] ?? ''); ?>" placeholder="Harga" required><br>
        <input type="text" name="gambar_buku" value="<?php echo htmlspecialchars($data['gambar_buku'] ?? ''); ?>" placeholder="URL Gambar Buku" required><br>
        <input type="submit" name="edit" value="Simpan Perubahan">
    </form>
</body>
</html>