<?php
  session_start();
  include("koneksi.php"); 

  if(isset($_POST['login'])) {
    $username = $_POST['username'];
    $password = $_POST['password'];

  
    $username = mysqli_real_escape_string($koneksi, $username);
    $password = mysqli_real_escape_string($koneksi, $password);

    $sql = "SELECT * FROM user WHERE username='$username' AND password='$password'";
    $result = mysqli_query($koneksi, $sql);

    if($result && mysqli_num_rows($result) > 0) { 
      $data = mysqli_fetch_assoc($result);
      if($data['role'] == 'user') {
        header('location: index.php'); 
        exit();
      } else if($data['role'] == 'admin') {
        header('location: admin.php'); 
        exit();
      } else if($data['role'] == 'superadmin') {
        header('location: superadmin.php');
        exit();
      }
    } else {
      echo "LOGIN GAGAL"; 
    }
  }
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>LOGIN</title>
  <style>
    
    body {
      font-family: Arial, sans-serif;
      display: flex;
      justify-content: center;
      align-items: center;
      min-height: 100vh;
      background-color: #f0f2f5;
      margin: 0;
    }
    .box {
      background-color: #fff;
      padding: 30px;
      border-radius: 8px;
      box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
      text-align: center;
    }
    form input[type="text"],
    form input[type="password"],
    form input[type="submit"] {
      width: 100%;
      padding: 10px;
      margin-bottom: 15px;
      border: 1px solid #ddd;
      border-radius: 4px;
      box-sizing: border-box; 
    }
    form input[type="submit"] {
      background-color: #007bff;
      color: white;
      border: none;
      cursor: pointer;
      font-size: 16px;
      transition: background-color 0.3s ease;
    }
    form input[type="submit"]:hover {
      background-color: #0056b3;
    }
  </style>
</head>
<body>
  <div class="box">
    <h2>Login</h2>
    <form action="login.php" method="post">
      <input type="text" name="username" placeholder="Username" required>
      <input type="password" name="password" placeholder="Password" required>
      <input type="submit" name="login" value="Login">
    </form>
  </div>
</body>
</html>