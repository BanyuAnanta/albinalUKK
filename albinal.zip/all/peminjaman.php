<?php
session_start();
include('koneksi.php');

// Check if connection is successful
if (!$koneksi) {
    die("Connection failed: " . mysqli_connect_error());
}

// Function to clean input data
function clean_input($data, $koneksi) {
    return mysqli_real_escape_string($koneksi, htmlspecialchars(trim($data)));
}

// Handle the borrow request
if (isset($_POST['pinjam'])) {
    $nama_buku = clean_input($_POST['nama_buku'], $koneksi);
    $tanggal = clean_input($_POST['tanggal'], $koneksi);
    $jumlah = clean_input($_POST['jumlah'], $koneksi);
    $alasan = clean_input($_POST['alasan'], $koneksi);

    // Insert the borrow record into the database
    $sql = "INSERT INTO pinjaman (nama_buku, tanggal, jumlah, alasan) VALUES ('$nama_buku', '$tanggal', '$jumlah', '$alasan')";

    if (mysqli_query($koneksi, $sql)) {
        $_SESSION['success_message'] = "Peminjaman berhasil!";
        header("location: pinjam.php");
        exit();
    } else {
        $_SESSION['error_message'] = "Error saat meminjam: " . mysqli_error($koneksi);
        header("location: pinjam.php");
        exit();
    }
}

// Fetch the list of books for the dropdown
$books = [];
$sql_select_books = "SELECT judul_buku FROM buku ORDER BY judul_buku ASC";
$result_books = mysqli_query($koneksi, $sql_select_books);

if ($result_books) {
    while ($row = mysqli_fetch_assoc($result_books)) {
        $books[] = $row['judul_buku'];
    }
} else {
    echo "<p>Error fetching books: " . mysqli_error($koneksi) . "</p>";
}

mysqli_close($koneksi);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Peminjaman Buku</title>
    <style>
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            margin: 0;
            background-color: #f4f7f6; /* Warna latar belakang lembut */
            color: #333;
            display: flex;
            flex-direction: column;
            align-items: center;
            min-height: 100vh;
            padding: 20px;
            box-sizing: border-box;
        }

        h2 {
            color: #007bff; /* Warna biru cerah */
            text-align: center;
            margin-top: 20px;
            margin-bottom: 30px;
            font-size: 2.2em;
            font-weight: 700;
        }

        .message {
            padding: 12px 20px;
            margin-bottom: 20px;
            border-radius: 8px;
            font-weight: bold;
            text-align: center;
            width: 100%;
            max-width: 500px;
            box-sizing: border-box;
            box-shadow: 0 2px 4px rgba(0,0,0,0.1);
        }

        .message.success {
            background-color: #d4edda;
            color: #155724;
            border: 1px solid #c3e6cb;
        }

        .message.error {
            background-color: #f8d7da;
            color: #721c24;
            border: 1px solid #f5c6cb;
        }

        form {
            background-color: #ffffff;
            padding: 40px;
            border-radius: 12px;
            box-shadow: 0 8px 16px rgba(0,0,0,0.15);
            max-width: 500px;
            width: 100%;
            box-sizing: border-box;
            display: flex;
            flex-direction: column;
            gap: 20px; /* Jarak antar elemen form */
        }

        form label {
            display: block;
            margin-bottom: 8px;
            font-weight: 600;
            color: #444;
            font-size: 1.05em;
        }

        form input[type="text"],
        form input[type="date"],
        form input[type="number"],
        form select,
        form textarea {
            width: 100%;
            padding: 14px;
            border: 1px solid #ced4da;
            border-radius: 8px;
            box-sizing: border-box;
            font-size: 1em;
            transition: border-color 0.3s ease, box-shadow 0.3s ease;
        }

        form input[type="text"]:focus,
        form input[type="date"]:focus,
        form input[type="number"]:focus,
        form select:focus,
        form textarea:focus {
            border-color: #007bff;
            box-shadow: 0 0 0 0.25rem rgba(0,123,255,.25);
            outline: none;
        }

        form textarea {
            resize: vertical; /* Memungkinkan textarea diresize secara vertikal */
            min-height: 100px; /* Tinggi minimum textarea */
        }

        form input[type="submit"] {
            background-color: #28a745; /* Warna hijau untuk tombol submit */
            color: white;
            padding: 15px 25px;
            border: none;
            border-radius: 8px;
            cursor: pointer;
            font-size: 1.15em;
            font-weight: 600;
            width: 100%;
            transition: background-color 0.3s ease, transform 0.2s ease;
            box-shadow: 0 4px 8px rgba(0,0,0,0.1);
        }

        form input[type="submit"]:hover {
            background-color: #218838;
            transform: translateY(-3px); /* Efek sedikit terangkat saat hover */
        }

        /* Responsive Adjustments */
        @media (max-width: 768px) {
            h2 { font-size: 1.8em; margin-bottom: 25px; }
            form { padding: 30px; gap: 15px; }
            .message { padding: 10px 15px; }
            form input, form select, form textarea { padding: 12px; font-size: 0.95em; }
            form input[type="submit"] { padding: 12px 20px; font-size: 1.05em; }
        }

        @media (max-width: 480px) {
            body { padding: 15px; }
            h2 { font-size: 1.6em; margin-bottom: 20px; }
            form { padding: 25px; border-radius: 10px; box-shadow: none; gap: 12px; }
            .message { border-radius: 6px; }
            form input, form select, form textarea { padding: 10px; font-size: 0.9em; }
            form input[type="submit"] { padding: 10px 18px; font-size: 1em; border-radius: 6px; }
        }
    </style>
</head>
<body>
    <h2>Peminjaman Buku</h2>
    <?php
    // Display success or error messages
    if (isset($_SESSION['success_message'])) {
        echo '<div class="message success">' . $_SESSION['success_message'] . '</div>';
        unset($_SESSION['success_message']);
    }
    if (isset($_SESSION['error_message'])) {
        echo '<div class="message error">' . $_SESSION['error_message'] . '</div>';
        unset($_SESSION['error_message']);
    }
    ?>

    <form action="" method="post">
        <label for="nama_buku">Nama Buku:</label>
        <select name="nama_buku" id="nama_buku" required>
            <option value="">Pilih Buku</option>
            <?php foreach ($books as $book) { ?>
                <option value="<?php echo htmlspecialchars($book); ?>"><?php echo htmlspecialchars($book); ?></option>
            <?php } ?>
        </select>

        <label for="tanggal">Tanggal Peminjaman:</label>
        <input type="date" name="tanggal" id="tanggal" value="<?php echo date('Y-m-d'); ?>" required> <label for="jumlah">Jumlah:</label>
        <input type="number" name="jumlah" id="jumlah" min="1" value="1" required> <label for="alasan">Alasan:</label>
        <textarea name="alasan" id="alasan" rows="4" placeholder="Contoh: Untuk keperluan tugas sekolah" required></textarea>

        <input type="submit" name="pinjam" value="Pinjam Buku">
    </form>
</body>
</html>
