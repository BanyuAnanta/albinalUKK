<?php
session_start();
include('koneksi.php'); // Pastikan file koneksi.php sudah ada dan benar

// Check if connection is successful
if (!$koneksi) {
    die("Connection failed: " . mysqli_connect_error());
}

// Function to clean input data
function clean_input($data) {
    // Using mysqli_real_escape_string would require $koneksi to be passed here
    // For prepared statements, htmlspecialchars and trim are often sufficient.
    return htmlspecialchars(trim($data));
}

// Handle the return request
if (isset($_POST['proses_pengembalian'])) {
    $id_pinjaman = isset($_POST['id_pinjaman']) ? (int)clean_input($_POST['id_pinjaman']) : 0;
    $nama_buku_dikembalikan = clean_input($_POST['nama_buku_dikembalikan']); // Hidden input from form
    $tanggal_pengembalian = date('Y-m-d'); // Tanggal otomatis hari ini
    $status_pengembalian = clean_input($_POST['status_pengembalian']);

    if ($id_pinjaman > 0 && !empty($nama_buku_dikembalikan) && !empty($status_pengembalian)) {
        // Start a transaction for atomicity
        mysqli_begin_transaction($koneksi);

        try {
            // 1. Update the 'pinjaman' table: Set tanggal_kembali and status
            $stmt_update_pinjaman = mysqli_prepare($koneksi, "UPDATE pinjaman SET tanggal_kembali = ?, status = ? WHERE id_pinjaman = ?");
            if (!$stmt_update_pinjaman) {
                throw new Exception("Error preparing update pinjaman statement: " . mysqli_error($koneksi));
            }
            mysqli_stmt_bind_param($stmt_update_pinjaman, "ssi", $tanggal_pengembalian, $status_pengembalian, $id_pinjaman);
            if (!mysqli_stmt_execute($stmt_update_pinjaman)) {
                throw new Exception("Error executing update pinjaman: " . mysqli_error($koneksi));
            }
            mysqli_stmt_close($stmt_update_pinjaman);

            // 2. Insert into the 'pengembalian' table
            // Based on your image, 'pengembalian' has 'nama_buku', 'tanggal_pengembalian', 'status'.
            // I'll add 'id_pinjaman' to 'pengembalian' for better tracking.
            $stmt_insert_pengembalian = mysqli_prepare($koneksi, "INSERT INTO pengembalian (id_pinjaman, nama_buku, tanggal_pengembalian, status_pengembalian) VALUES (?, ?, ?, ?)");
            if (!$stmt_insert_pengembalian) {
                throw new Exception("Error preparing insert pengembalian statement: " . mysqli_error($koneksi));
            }
            mysqli_stmt_bind_param($stmt_insert_pengembalian, "isss", $id_pinjaman, $nama_buku_dikembalikan, $tanggal_pengembalian, $status_pengembalian);
            if (!mysqli_stmt_execute($stmt_insert_pengembalian)) {
                throw new Exception("Error executing insert pengembalian: " . mysqli_error($koneksi));
            }
            mysqli_stmt_close($stmt_insert_pengembalian);

            // If all queries successful, commit the transaction
            mysqli_commit($koneksi);
            $_SESSION['success_message'] = "Pengembalian buku berhasil dicatat!";

        } catch (Exception $e) {
            // If any error occurs, rollback the transaction
            mysqli_rollback($koneksi);
            $_SESSION['error_message'] = "Proses pengembalian gagal: " . $e->getMessage();
        }
    } else {
        $_SESSION['error_message'] = "Data pengembalian tidak lengkap atau tidak valid.";
    }

    header("Location: " . $_SERVER['PHP_SELF']); // Redirect to prevent form re-submission
    exit();
}

// Fetch active loans (books that are currently borrowed)
// Assuming 'pinjaman' table has columns: id_pinjaman, nama_buku, tanggal_pinjam, tanggal_kembali, jumlah, status
$active_loans = [];
$sql_active_loans = "SELECT
                        id_pinjaman,
                        nama_buku,
                        tanggal_pinjam,
                        jumlah,
                        status
                    FROM
                        pinjaman
                    WHERE
                        status = 'Dipinjam' OR tanggal_kembali IS NULL OR tanggal_kembali = '0000-00-00'
                    ORDER BY
                        tanggal_pinjam DESC";

$result_active_loans = mysqli_query($koneksi, $sql_active_loans);

if (!$result_active_loans) {
    // Tambahkan baris ini untuk melihat pesan error
    echo "Error pada query: " . mysqli_error($koneksi);
    // Hentikan eksekusi script agar tidak melanjutkan dengan data yang salah
    die();
}

if ($result_active_loans) {
    while ($row = mysqli_fetch_assoc($result_active_loans)) {
        $active_loans[] = $row;
    }
} else {
    $_SESSION['error_message'] = "Error fetching active loans: " . mysqli_error($koneksi);
}

mysqli_close($koneksi);
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Pengembalian Buku</title>
    <style>
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background-color: #f4f7f6; /* Warna latar belakang lembut */
            margin: 0;
            padding: 20px;
            color: #333;
            display: flex;
            flex-direction: column;
            align-items: center;
            min-height: 100vh;
            box-sizing: border-box;
        }

        h2 {
            color: #007bff; /* Warna biru cerah */
            text-align: center;
            margin-top: 20px;
            margin-bottom: 30px;
            font-size: 2.2em;
            font-weight: 700;
        }

        .message {
            padding: 12px 20px;
            margin-bottom: 20px;
            border-radius: 8px;
            font-weight: bold;
            text-align: center;
            width: 100%;
            max-width: 800px;
            box-sizing: border-box;
            box-shadow: 0 2px 4px rgba(0,0,0,0.1);
        }

        .message.success {
            background-color: #d4edda;
            color: #155724;
            border: 1px solid #c3e6cb;
        }

        .message.error {
            background-color: #f8d7da;
            color: #721c24;
            border: 1px solid #f5c6cb;
        }

        .table-container {
            width: 100%;
            max-width: 900px; /* Lebar maksimum tabel */
            margin-bottom: 50px;
            overflow-x: auto; /* Scroll horizontal untuk layar kecil */
            background-color: #ffffff;
            border-radius: 12px; /* Sudut membulat */
            box-shadow: 0 10px 25px rgba(0,0,0,0.1); /* Bayangan lebih halus */
            border: 1px solid #e0e6ed; /* Border tipis */
        }

        table {
            width: 100%;
            border-collapse: collapse; /* Garis antar sel menyatu */
        }

        table thead {
            background-color: #3498db; /* Biru cerah untuk header */
            color: white;
        }

        table thead th {
            padding: 18px 25px;
            text-align: left;
            white-space: nowrap; /* Mencegah teks header wrapping */
            font-size: 1.1em;
            font-weight: 600;
            border-bottom: 3px solid #2980b9; /* Border bawah lebih tebal */
        }

        table tbody td {
            padding: 15px 25px;
            border-bottom: 1px solid #ebf0f5; /* Garis antar baris */
            vertical-align: middle;
            font-size: 1em;
            color: #4a4a4a;
        }

        table tbody tr:nth-child(even) {
            background-color: #f7f9fc; /* Latar belakang abu-abu untuk baris genap */
        }

        table tbody tr:hover {
            background-color: #eef4f9; /* Efek hover lebih terang */
            transition: background-color 0.2s ease-in-out;
        }

        .no-records {
            text-align: center;
            padding: 30px;
            color: #7f8c8d; /* Warna teks abu-abu */
            font-style: italic;
            background-color: #ffffff;
            border-bottom: 1px solid #ebf0f5;
        }

        .return-btn {
            background-color: #dc3545; /* Merah untuk tombol pengembalian */
            color: white;
            padding: 8px 15px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            font-size: 0.9em;
            transition: background-color 0.3s ease, transform 0.2s ease;
            text-decoration: none; /* Jika digunakan sebagai link */
            display: inline-block; /* Untuk padding yang lebih baik */
        }
        .return-btn:hover {
            background-color: #c82333;
            transform: translateY(-2px); /* Efek sedikit terangkat saat hover */
        }

        /* Modal Styles (untuk form pengembalian) */
        .modal {
            display: none; /* Hidden by default */
            position: fixed; /* Stay in place */
            z-index: 1000; /* Sit on top, higher than other elements */
            left: 0;
            top: 0;
            width: 100%; /* Full width */
            height: 100%; /* Full height */
            overflow: auto; /* Enable scroll if needed */
            background-color: rgba(0,0,0,0.6); /* Black w/ opacity */
            display: flex; /* Use flexbox to center content */
            align-items: center; /* Center vertically */
            justify-content: center; /* Center horizontally */
            padding: 20px;
            box-sizing: border-box;
        }

        .modal-content {
            background-color: #fefefe;
            margin: auto;
            padding: 30px;
            border-radius: 10px;
            width: 90%;
            max-width: 450px;
            box-shadow: 0 10px 20px rgba(0,0,0,0.2);
            position: relative;
            animation: fadeIn 0.3s ease-out; /* Animasi saat muncul */
        }

        @keyframes fadeIn {
            from { opacity: 0; transform: translateY(-20px); }
            to { opacity: 1; transform: translateY(0); }
        }

        .close-button {
            color: #aaa;
            position: absolute;
            top: 10px;
            right: 20px;
            font-size: 32px;
            font-weight: bold;
            cursor: pointer;
            transition: color 0.3s ease;
        }

        .close-button:hover,
        .close-button:focus {
            color: #333;
            text-decoration: none;
        }

        .modal-content h3 {
            color: #dc3545; /* Merah untuk judul modal pengembalian */
            text-align: center;
            margin-bottom: 25px;
            font-size: 1.8em;
            font-weight: 600;
        }

        .modal-content form {
            display: flex;
            flex-direction: column;
            gap: 15px;
        }

        .modal-content label {
            display: block;
            margin-bottom: 5px;
            font-weight: 500;
            color: #555;
        }

        .modal-content input[type="text"],
        .modal-content input[type="date"],
        .modal-content select,
        .modal-content textarea {
            width: 100%;
            padding: 10px;
            border: 1px solid #ced4da;
            border-radius: 5px;
            box-sizing: border-box;
            font-size: 1em;
            transition: border-color 0.3s ease, box-shadow 0.3s ease;
        }
        .modal-content input[type="text"]:focus,
        .modal-content input[type="date"]:focus,
        .modal-content select:focus,
        .modal-content textarea:focus {
            border-color: #dc3545; /* Warna fokus merah */
            box-shadow: 0 0 0 0.25rem rgba(220,53,69,.25);
            outline: none;
        }
        .modal-content textarea {
            resize: vertical;
            min-height: 80px;
        }

        .modal-content input[type="submit"] {
            background-color: #28a745; /* Hijau untuk tombol submit di modal */
            color: white;
            padding: 12px 20px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            font-size: 1.05em;
            font-weight: 600;
            transition: background-color 0.3s ease, transform 0.2s ease;
        }

        .modal-content input[type="submit"]:hover {
            background-color: #218838;
            transform: translateY(-2px);
        }

        /* Responsive adjustments */
        @media (max-width: 768px) {
            h2 { font-size: 1.8em; margin-bottom: 25px; }
            .table-container { margin: 15px; border-radius: 8px; box-shadow: 0 5px 15px rgba(0,0,0,0.1); }
            table thead th, table tbody td { padding: 12px 18px; font-size: 0.9em; }
            .return-btn { padding: 6px 10px; font-size: 0.8em; }
            .modal-content { padding: 25px; }
            .modal-content h3 { font-size: 1.6em; }
            .close-button { font-size: 28px; top: 5px; right: 15px; }
        }
        @media (max-width: 480px) {
            body { padding: 10px; }
            h2 { font-size: 1.5em; margin-bottom: 20px; }
            .table-container { border-radius: 5px; box-shadow: none; border: none; }
            table { font-size: 0.8em; }
            table thead th, table tbody td { padding: 10px 12px; }
            .return-btn { padding: 5px 8px; font-size: 0.75em; }
            .modal-content { padding: 20px; border-radius: 5px; }
            .modal-content h3 { font-size: 1.4em; margin-bottom: 20px; }
            .close-button { font-size: 24px; top: 2px; right: 10px; }
        }
    </style>
</head>
<body>
    <h2>Pengembalian Buku</h2>

    <?php
    // Display success or error messages
    if (isset($_SESSION['success_message'])) {
        echo '<div class="message success">' . $_SESSION['success_message'] . '</div>';
        unset($_SESSION['success_message']);
    }
    if (isset($_SESSION['error_message'])) {
        echo '<div class="message error">' . $_SESSION['error_message'] . '</div>';
        unset($_SESSION['error_message']);
    }
    ?>

    <div class="table-container">
        <table>
            <thead>
                <tr>
                    <th>ID Pinjaman</th>
                    <th>Nama Buku</th>
                    <th>Jumlah</th>
                    <th>Tanggal Pinjam</th>
                    <th>Status</th>
                    <th>Aksi</th>
                </tr>
            </thead>
            <tbody>
                <?php if (!empty($active_loans)): ?>
                    <?php foreach($active_loans as $loan): ?>
                        <tr>
                            <td><?= htmlspecialchars($loan['id_pinjaman']); ?></td>
                            <td><?= htmlspecialchars($loan['nama_buku']); ?></td>
                            <td><?= htmlspecialchars($loan['jumlah']); ?></td>
                            <td><?= htmlspecialchars($loan['tanggal_pinjam']); ?></td>
                            <td>
                                <span style="
                                    display: inline-block;
                                    padding: 4px 8px;
                                    border-radius: 4px;
                                    font-weight: bold;
                                    background-color: #d1ecf1; /* Light blue for 'Dipinjam' */
                                    color: #0c5460;
                                ">
                                    <?= htmlspecialchars($loan['status']); ?>
                                </span>
                            </td>
                            <td>
                                <button class="return-btn"
                                        data-id-pinjaman="<?= htmlspecialchars($loan['id_pinjaman']); ?>"
                                        data-nama-buku="<?= htmlspecialchars($loan['nama_buku']); ?>">
                                    Kembalikan
                                </button>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                <?php else: ?>
                    <tr>
                        <td colspan="6" class="no-records">Tidak ada buku yang sedang dipinjam saat ini.</td>
                    </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>

    <div id="returnModal" class="modal" style="display: none;">
        <div class="modal-content">
            <span class="close-button">&times;</span>
            <h3>Form Pengembalian Buku</h3>
            <form action="" method="post">
                <input type="hidden" id="modal_id_pinjaman" name="id_pinjaman">
                
                <label for="modal_nama_buku">Judul Buku:</label>
                <input type="text" id="modal_nama_buku" name="nama_buku_display" readonly>
                <input type="hidden" id="hidden_nama_buku_dikembalikan" name="nama_buku_dikembalikan"> <label for="modal_tanggal_pengembalian">Tanggal Pengembalian:</label>
                <input type="date" id="modal_tanggal_pengembalian" name="tanggal_pengembalian_form" value="<?php echo date('Y-m-d'); ?>" readonly>

                <label for="modal_status_pengembalian">Status Pengembalian:</label>
                <select id="modal_status_pengembalian" name="status_pengembalian" required>
                    <option value="Dikembalikan">Dikembalikan (Normal)</option>
                    <option value="Terlambat">Dikembalikan (Terlambat)</option>
                    <option value="Rusak">Dikembalikan (Rusak)</option>
                    <option value="Hilang">Dikembalikan (Hilang)</option>
                </select>

                <input type="submit" name="proses_pengembalian" value="Konfirmasi Pengembalian">
            </form>
        </div>
    </div>

    <script>
        // Get the modal
        var returnModal = document.getElementById("returnModal");

        // Get the <span> element that closes the modal
        var closeButton = document.getElementsByClassName("close-button")[0];

        // Get all buttons that open the modal
        var returnBtns = document.querySelectorAll(".return-btn");

        // When the user clicks on a return button, open the modal and populate data
        returnBtns.forEach(function(btn) {
            btn.onclick = function() {
                var idPinjaman = this.getAttribute("data-id-pinjaman");
                var namaBuku = this.getAttribute("data-nama-buku");

                document.getElementById("modal_id_pinjaman").value = idPinjaman;
                document.getElementById("modal_nama_buku").value = namaBuku; // For display
                document.getElementById("hidden_nama_buku_dikembalikan").value = namaBuku; // For sending to PHP
                document.getElementById("modal_tanggal_pengembalian").value = '<?php echo date('Y-m-d'); ?>'; // Default to current date
                document.getElementById("modal_status_pengembalian").value = "Dikembalikan"; // Default status

                returnModal.style.display = "flex"; // Use flex to center
            }
        });

        // When the user clicks on <span> (x), close the modal
        closeButton.onclick = function() {
            returnModal.style.display = "none";
        }

        // When the user clicks anywhere outside of the modal, close it
        window.onclick = function(event) {
            if (event.target == returnModal) {
                returnModal.style.display = "none";
            }
        }
    </script>
</body>
</html>