<?php
session_start();
include('koneksi.php');

// Check if connection is successful
if (!$koneksi) {
    die("Connection failed: " . mysqli_connect_error());
}

// Function to clean input data (using prepared statements later, but still good for basic cleaning)
function clean_input($data) {
    return htmlspecialchars(trim($data));
}

// Handle the borrow request
if (isset($_POST['pinjam_buku'])) { // Changed submit button name
    $no_buku_dipinjam = clean_input($_POST['no_buku_dipinjam']); // Use no_buku
    $tanggal_pinjam = clean_input($_POST['tanggal_pinjam']);
    $jumlah_pinjam = (int)clean_input($_POST['jumlah_pinjam']); // Ensure it's an integer
    $alasan = clean_input($_POST['alasan']);

    // Input validation
    if (empty($no_buku_dipinjam) || empty($tanggal_pinjam) || $jumlah_pinjam <= 0 || empty($alasan)) {
        $_SESSION['error_message'] = "Harap isi semua kolom dengan benar.";
    } else {
        // Use prepared statement for security! (CRITICAL)
        // Ensure table name is 'pinjaman' and columns match (no_buku_dipinjam, tanggal_pinjam, jumlah_pinjam, alasan)
        $stmt = mysqli_prepare($koneksi, "INSERT INTO pinjaman (no_buku_dipinjam, tanggal_pinjam, jumlah_pinjam, alasan) VALUES (?, ?, ?, ?)");

        if ($stmt) {
            // "ssis" -> s=string (no_buku), s=string (tanggal), i=integer (jumlah), s=string (alasan)
            mysqli_stmt_bind_param($stmt, "ssis", $no_buku_dipinjam, $tanggal_pinjam, $jumlah_pinjam, $alasan);

            if (mysqli_stmt_execute($stmt)) {
                $_SESSION['success_message'] = "Peminjaman buku berhasil dicatat!";
            } else {
                $_SESSION['error_message'] = "Error saat menyimpan peminjaman: " . mysqli_error($koneksi);
            }
            mysqli_stmt_close($stmt);
        } else {
            $_SESSION['error_message'] = "Error dalam menyiapkan query peminjaman: " . mysqli_error($koneksi);
        }
    }
    // Redirect to prevent form re-submission and clear POST data
    header("Location: " . $_SERVER['PHP_SELF']);
    exit();
}


$books = [];

// Fetch the list of books for the table display
$sql_select_books = "SELECT kode_buku, no_buku, judul_buku, tahun_terbit, penulis, penerbit, jumlah_halaman, gambar_buku FROM buku ORDER BY judul_buku ASC";
$result_books = mysqli_query($koneksi, $sql_select_books);

if ($result_books) {
    while($row = mysqli_fetch_assoc($result_books)) {
        $books[] = $row;
    }
} else {
    $_SESSION['error_message'] = "Error fetching books from database: " . mysqli_error($koneksi);
}

mysqli_close($koneksi);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Daftar Koleksi Buku</title>
    <style>
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background-color: #f4f7f6;
            margin: 0;
            padding: 20px;
            color: #333;
            display: flex;
            flex-direction: column;
            align-items: center;
            min-height: 100vh;
            box-sizing: border-box;
        }
        h2 {
            color: #007bff;
            text-align: center;
            margin-top: 20px;
            margin-bottom: 30px;
            font-size: 2.2em;
            font-weight: 700;
        }
        .message {
            padding: 12px 20px;
            margin-bottom: 20px;
            border-radius: 8px;
            font-weight: bold;
            text-align: center;
            width: 100%;
            max-width: 800px;
            box-sizing: border-box;
            box-shadow: 0 2px 4px rgba(0,0,0,0.1);
        }
        .message.success {
            background-color: #d4edda;
            color: #155724;
            border: 1px solid #c3e6cb;
        }
        .message.error {
            background-color: #f8d7da;
            color: #721c24;
            border: 1px solid #f5c6cb;
        }
        .table-container {
            width: 100%;
            max-width: 1200px; /* Increased max-width for better display of many columns */
            margin-bottom: 50px;
            overflow-x: auto; /* Enable horizontal scrolling for small screens */
            box-shadow: 0 6px 12px rgba(0,0,0,0.1);
            border-radius: 10px;
        }
        table {
            width: 100%;
            border-collapse: collapse;
            background-color: #ffffff;
            border-radius: 10px;
            overflow: hidden; /* Important for rounded corners */
        }
        table thead {
            background-color: #007bff;
            color: white;
        }
        table thead th {
            padding: 15px 18px;
            text-align: left;
            white-space: nowrap; /* Prevent wrapping for headers */
            font-size: 1.05em;
        }
        table tbody td {
            padding: 12px 18px;
            border-bottom: 1px solid #e9ecef;
            vertical-align: middle;
            font-size: 0.95em;
        }
        table tbody tr:nth-child(even) {
            background-color: #f8f9fa;
        }
        table tbody tr:hover {
            background-color: #e2e6ea;
        }
        table img {
            max-width: 80px;
            height: auto;
            display: block;
            border-radius: 6px;
            box-shadow: 0 2px 5px rgba(0,0,0,0.1);
        }
        .no-records {
            text-align: center;
            padding: 25px;
            color: #6c757d;
            font-style: italic;
            background-color: #f8f9fa;
        }
        .borrow-btn {
            background-color: #28a745; /* Green */
            color: white;
            padding: 8px 15px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            font-size: 0.9em;
            transition: background-color 0.3s ease, transform 0.2s ease;
            text-decoration: none; /* If it's an anchor */
            display: inline-block; /* For better padding */
        }
        .borrow-btn:hover {
            background-color: #218838;
            transform: translateY(-2px);
        }

        /* Modal Styles */
        .modal {
            display: none; /* Hidden by default */
            position: fixed; /* Stay in place */
            z-index: 1; /* Sit on top */
            left: 0;
            top: 0;
            width: 100%; /* Full width */
            height: 100%; /* Full height */
            overflow: auto; /* Enable scroll if needed */
            background-color: rgba(0,0,0,0.6); /* Black w/ opacity */
            display: flex; /* Use flexbox to center content */
            align-items: center; /* Center vertically */
            justify-content: center; /* Center horizontally */
            padding: 20px;
            box-sizing: border-box;
        }

        .modal-content {
            background-color: #fefefe;
            margin: auto;
            padding: 30px;
            border-radius: 10px;
            width: 90%;
            max-width: 500px;
            box-shadow: 0 10px 20px rgba(0,0,0,0.2);
            position: relative;
            animation: fadeIn 0.3s ease-out;
        }

        @keyframes fadeIn {
            from { opacity: 0; transform: translateY(-20px); }
            to { opacity: 1; transform: translateY(0); }
        }

        .close-button {
            color: #aaa;
            position: absolute;
            top: 10px;
            right: 20px;
            font-size: 32px;
            font-weight: bold;
            cursor: pointer;
            transition: color 0.3s ease;
        }

        .close-button:hover,
        .close-button:focus {
            color: #333;
            text-decoration: none;
        }

        .modal-content h3 {
            color: #007bff;
            text-align: center;
            margin-bottom: 25px;
            font-size: 1.8em;
            font-weight: 600;
        }

        .modal-content form {
            display: flex;
            flex-direction: column;
            gap: 15px;
        }

        .modal-content label {
            display: block;
            margin-bottom: 5px;
            font-weight: 500;
            color: #555;
        }

        .modal-content input[type="text"],
        .modal-content input[type="date"],
        .modal-content input[type="number"],
        .modal-content textarea {
            width: 100%;
            padding: 10px;
            border: 1px solid #ced4da;
            border-radius: 5px;
            box-sizing: border-box;
            font-size: 1em;
        }
        .modal-content textarea {
            resize: vertical;
            min-height: 80px;
        }

        .modal-content input[type="submit"] {
            background-color: #007bff;
            color: white;
            padding: 12px 20px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            font-size: 1.05em;
            font-weight: 600;
            transition: background-color 0.3s ease;
        }

        .modal-content input[type="submit"]:hover {
            background-color: #0056b3;
        }

        /* Responsive adjustments */
        @media (max-width: 768px) {
            h2 { font-size: 1.8em; }
            .table-container { margin: 15px; }
            table thead th, table tbody td { padding: 10px 12px; font-size: 0.9em; }
            table img { max-width: 60px; }
            .borrow-btn { padding: 6px 10px; font-size: 0.8em; }
            .modal-content { padding: 25px; }
            .modal-content h3 { font-size: 1.6em; }
            .close-button { font-size: 28px; top: 5px; right: 15px; }
        }
        @media (max-width: 480px) {
            body { padding: 10px; }
            h2 { font-size: 1.5em; }
            .table-container { border-radius: 0; box-shadow: none; }
            table { font-size: 0.8em; }
            table thead th, table tbody td { padding: 8px 10px; }
            table img { max-width: 50px; }
            .borrow-btn { padding: 5px 8px; font-size: 0.75em; }
            .modal-content { padding: 20px; border-radius: 5px; }
            .modal-content h3 { font-size: 1.4em; margin-bottom: 20px; }
            .close-button { font-size: 24px; top: 2px; right: 10px; }
        }
    </style>
</head>
<body>
    <h2>Daftar Koleksi Buku</h2>

    <?php
    // Display success or error messages (using session messages for better UX)
    if (isset($_SESSION['success_message'])) {
        echo '<div class="message success">' . $_SESSION['success_message'] . '</div>';
        unset($_SESSION['success_message']);
    }
    if (isset($_SESSION['error_message'])) {
        echo '<div class="message error">' . $_SESSION['error_message'] . '</div>';
        unset($_SESSION['error_message']);
    }
    ?>

    <div class="table-container">
        <table>
            <thead>
                <tr>
                    <th>KODE BUKU</th>
                    <th>NO BUKU</th>
                    <th>JUDUL BUKU</th>
                    <th>TAHUN TERBIT</th>
                    <th>PENULIS</th>
                    <th>PENERBIT</th>
                    <th>JUMLAH HALAMAN</th>
                    <th>GAMBAR</th>
                    <th>AKSI</th> </tr>
            </thead>
            <tbody>
                <?php
                if (!empty($books)) {
                    foreach($books as $data) {
                ?>
                    <tr>
                        <td><?php echo htmlspecialchars($data['kode_buku']); ?></td>
                        <td><?php echo htmlspecialchars($data['no_buku']); ?></td>
                        <td><?php echo htmlspecialchars($data['judul_buku']); ?></td>
                        <td><?php echo htmlspecialchars($data['tahun_terbit']); ?></td>
                        <td><?php echo htmlspecialchars($data['penulis']); ?></td>
                        <td><?php echo htmlspecialchars($data['penerbit']); ?></td>
                        <td><?php echo htmlspecialchars($data['jumlah_halaman']); ?></td>
                        <td><img src="<?php echo htmlspecialchars($data['gambar_buku']); ?>" alt="cover"></td>
                        <td>
                            <button class="borrow-btn" 
                                    data-no-buku="<?php echo htmlspecialchars($data['no_buku']); ?>" 
                                    data-judul-buku="<?php echo htmlspecialchars($data['judul_buku']); ?>">
                                Pinjam
                            </button>
                        </td>
                    </tr>
                <?php
                    }
                } else {
                    echo "<tr><td colspan='9' class='no-records'>BELUM ADA DATA BUKU YANG TERSEDIA.</td></tr>";
                }
                ?>
            </tbody>
        </table>
    </div>

    <div id="borrowModal" class="modal">
        <div class="modal-content">
            <span class="close-button">&times;</span>
            <h3>Form Peminjaman Buku</h3>
            <form action="" method="post">
                <label for="modal_judul_buku">Judul Buku:</label>
                <input type="text" id="modal_judul_buku" name="judul_buku_display" readonly>
                <input type="hidden" id="modal_no_buku" name="no_buku_dipinjam"> <label for="modal_tanggal_pinjam">Tanggal Peminjaman:</label>
                <input type="date" id="modal_tanggal_pinjam" name="tanggal_pinjam" value="<?php echo date('Y-m-d'); ?>" required>

                <label for="modal_jumlah_pinjam">Jumlah:</label>
                <input type="number" id="modal_jumlah_pinjam" name="jumlah_pinjam" min="1" value="1" required>

                <label for="modal_alasan">Alasan:</label>
                <textarea id="modal_alasan" name="alasan" rows="4" placeholder="Contoh: Untuk tugas sekolah/dibaca sendiri" required></textarea>

                <input type="submit" name="pinjam_buku" value="Konfirmasi Pinjaman">
            </form>
        </div>
    </div>

    <script>
        // Get the modal
        var modal = document.getElementById("borrowModal");

        // Get the <span> element that closes the modal
        var span = document.getElementsByClassName("close-button")[0];

        // Get all buttons that open the modal
        var borrowBtns = document.querySelectorAll(".borrow-btn");

        // When the user clicks on a borrow button, open the modal and populate data
        borrowBtns.forEach(function(btn) {
            btn.onclick = function() {
                var noBuku = this.getAttribute("data-no-buku");
                var judulBuku = this.getAttribute("data-judul-buku");

                document.getElementById("modal_judul_buku").value = judulBuku;
                document.getElementById("modal_no_buku").value = noBuku; // Set hidden input
                document.getElementById("modal_jumlah_pinjam").value = 1; // Reset jumlah to 1
                document.getElementById("modal_alasan").value = ""; // Clear previous reason

                modal.style.display = "flex"; // Use flex to center
            }
        });

        // When the user clicks on <span> (x), close the modal
        span.onclick = function() {
            modal.style.display = "none";
        }

        // When the user clicks anywhere outside of the modal, close it
        window.onclick = function(event) {
            if (event.target == modal) {
                modal.style.display = "none";
            }
        }
    </script>
</body>
</html>