<?php
session_start();
include('koneksi.php'); // Pastikan file koneksi.php ada dan berfungsi dengan baik

// Fungsi untuk membersihkan dan memvalidasi input
function clean_input($data, $koneksi) {
    $data = trim($data); // Hapus spasi di awal/akhir
    $data = stripslashes($data); // Hapus backslashes
    $data = htmlspecialchars($data); // Konversi karakter khusus ke entitas HTML
    $data = mysqli_real_escape_string($koneksi, $data); // Lindungi dari SQL injection
    return $data;
}

// Handle pengiriman formulir Tambah Buku
if (isset($_POST['tambah'])) {
    // Bersihkan dan validasi semua input
    $kode_buku      = clean_input($_POST['kode_buku'], $koneksi);
    $no_buku        = clean_input($_POST['no_buku'], $koneksi);
    $judul_buku     = clean_input($_POST['judul_buku'], $koneksi);
    $tahun_terbit   = clean_input($_POST['tahun_terbit'], $koneksi);
    $nama_penulis   = clean_input($_POST['penulis'], $koneksi); // Perhatikan nama variabel
    $penerbit       = clean_input($_POST['penerbit'], $koneksi);
    $jumlah_halaman = clean_input($_POST['jumlah_halaman'], $koneksi);
    $harga          = clean_input($_POST['harga'], $koneksi);
    $gambar_buku    = clean_input($_POST['gambar_buku'], $koneksi);

    // Validasi tambahan untuk tahun terbit (jika perlu, misalnya harus 4 digit angka)
    if (!empty($tahun_terbit) && !preg_match("/^\d{4}$/", $tahun_terbit)) {
        $_SESSION['error_message'] = "Tahun Terbit harus berupa 4 digit angka.";
        header("location: admin.php");
        exit();
    }
    // Validasi harga dan jumlah halaman
    if (!is_numeric($harga) || $harga < 0) {
        $_SESSION['error_message'] = "Harga harus berupa angka positif.";
        header("location: admin.php");
        exit();
    }
    if (!is_numeric($jumlah_halaman) || $jumlah_halaman < 0) {
        $_SESSION['error_message'] = "Jumlah Halaman harus berupa angka positif.";
        header("location: admin.php");
        exit();
    }


    $sql = "INSERT INTO buku (kode_buku, no_buku, judul_buku, tahun_terbit, penulis, penerbit, jumlah_halaman, harga, gambar_buku)
            VALUES ('$kode_buku', '$no_buku', '$judul_buku', '$tahun_terbit', '$nama_penulis', '$penerbit', '$jumlah_halaman', '$harga', '$gambar_buku')";

    if (mysqli_query($koneksi, $sql)) {
        $_SESSION['success_message'] = "Buku berhasil ditambahkan!";
        header("location: admin.php");
        exit();
    } else {
        $_SESSION['error_message'] = "Error saat menambahkan buku: " . mysqli_error($koneksi);
        // Tetap di halaman admin.php agar pesan error terlihat
        header("location: admin.php"); // Atau Anda bisa echo error langsung di sini
        exit();
    }
}

// Handle aksi Hapus Buku
if (isset($_GET['action']) && $_GET['action'] == 'delete' && isset($_GET['id'])) {
    $no_buku_to_delete = clean_input($_GET['id'], $koneksi);

    $sql_delete = "DELETE FROM buku WHERE no_buku = '$no_buku_to_delete'";

    if (mysqli_query($koneksi, $sql_delete)) {
        $_SESSION['success_message'] = "Buku berhasil dihapus!";
        header("location: admin.php");
        exit();
    } else {
        $_SESSION['error_message'] = "Error saat menghapus buku: " . mysqli_error($koneksi);
        header("location: admin.php");
        exit();
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Tambah & Kelola Buku</title>
    <style>
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            margin: 0;
            background-color: #e9f0f6; /* Warna latar belakang lebih lembut */
            color: #333;
            display: flex;
            flex-direction: column;
            align-items: center;
            min-height: 100vh;
            padding: 20px; /* Tambahkan padding agar tidak terlalu mepet ke tepi */
            box-sizing: border-box;
        }
        h2 {
            color: #007bff; /* Warna biru yang lebih cerah */
            text-align: center;
            margin-top: 20px;
            margin-bottom: 25px;
            font-size: 2em;
            font-weight: 600;
        }
        .message {
            padding: 12px 20px;
            margin-bottom: 20px;
            border-radius: 6px;
            font-weight: bold;
            text-align: center;
            width: 100%;
            max-width: 500px;
            box-sizing: border-box;
        }
        .message.success {
            background-color: #d4edda;
            color: #155724;
            border: 1px solid #c3e6cb;
        }
        .message.error {
            background-color: #f8d7da;
            color: #721c24;
            border: 1px solid #f5c6cb;
        }

        .form-container {
            width: 100%;
            display: flex;
            justify-content: center;
            margin-bottom: 40px;
        }
        form {
            background-color: #ffffff;
            padding: 35px; /* Padding lebih besar */
            border-radius: 10px; /* Sudut lebih membulat */
            box-shadow: 0 6px 12px rgba(0,0,0,0.15); /* Bayangan lebih dalam */
            max-width: 450px; /* Lebar form sedikit ditingkatkan */
            width: 100%;
            box-sizing: border-box;
        }
        form input[type="text"],
        form input[type="number"] {
            width: 100%;
            padding: 14px; /* Padding input lebih besar */
            margin-bottom: 18px; /* Spasi antar input lebih banyak */
            border: 1px solid #ced4da; /* Warna border lebih soft */
            border-radius: 6px; /* Sudut input lebih membulat */
            box-sizing: border-box;
            font-size: 1em;
            transition: border-color 0.3s ease, box-shadow 0.3s ease;
        }
        form input[type="text"]:focus,
        form input[type="number"]:focus {
            border-color: #007bff;
            box-shadow: 0 0 0 0.2rem rgba(0,123,255,.25);
            outline: none;
        }
        form input[type="submit"] {
            background-color: #28a745;
            color: white;
            padding: 14px 25px;
            border: none;
            border-radius: 6px;
            cursor: pointer;
            font-size: 1.1em;
            font-weight: 600;
            width: 100%;
            transition: background-color 0.3s ease, transform 0.2s ease;
        }
        form input[type="submit"]:hover {
            background-color: #218838;
            transform: translateY(-2px);
        }
        hr {
            border: 0;
            height: 1px;
            background: #cddcdc; /* Warna HR lebih gelap */
            margin: 40px 0;
            width: 90%;
            max-width: 1000px; /* Batasi lebar HR */
        }
        .table-container {
            width: 100%;
            max-width: 1100px; /* Lebar maksimum tabel */
            margin-bottom: 50px;
            overflow-x: auto;
            box-shadow: 0 6px 12px rgba(0,0,0,0.1); /* Bayangan lebih dalam */
            border-radius: 10px; /* Sudut lebih membulat */
        }
        table {
            width: 100%;
            border-collapse: collapse;
            background-color: #ffffff;
            border-radius: 10px;
            overflow: hidden; /* Penting untuk sudut membulat */
        }
        table thead {
            background-color: #007bff;
            color: white;
        }
        table thead th {
            padding: 15px 18px; /* Padding header lebih besar */
            text-align: left;
            white-space: nowrap;
            font-size: 1.05em;
        }
        table tbody td {
            padding: 12px 18px; /* Padding cell lebih besar */
            border-bottom: 1px solid #e9ecef; /* Garis antar baris lebih halus */
            vertical-align: middle;
            font-size: 0.95em;
        }
        table tbody tr:nth-child(even) {
            background-color: #f8f9fa; /* Warna striping lebih terang */
        }
        table tbody tr:hover {
            background-color: #e2e6ea; /* Warna hover lebih menonjol */
        }
        table img {
            max-width: 90px; /* Ukuran gambar sedikit lebih besar */
            height: auto;
            display: block;
            border-radius: 6px; /* Sudut gambar lebih membulat */
            box-shadow: 0 2px 5px rgba(0,0,0,0.1);
        }
        .action-links {
            white-space: nowrap;
        }
        .action-links a {
            text-decoration: none;
            padding: 8px 14px; /* Padding tombol aksi lebih besar */
            border-radius: 6px; /* Sudut tombol aksi lebih membulat */
            margin-right: 8px;
            display: inline-block;
            font-size: 0.9em;
            font-weight: 500;
            transition: background-color 0.3s ease, transform 0.2s ease;
        }
        .action-links a:last-child {
            margin-right: 0;
        }
        .action-links a.edit-btn {
            background-color: #007bff; /* Menggunakan warna biru primer */
            color: white;
        }
        .action-links a.edit-btn:hover {
            background-color: #0056b3;
            transform: translateY(-1px);
        }
        .action-links a.delete-btn {
            background-color: #dc3545;
            color: white;
        }
        .action-links a.delete-btn:hover {
            background-color: #c82333;
            transform: translateY(-1px);
        }
        .no-records {
            text-align: center;
            padding: 25px;
            color: #6c757d;
            font-style: italic;
            background-color: #f8f9fa;
        }

        /* Responsive adjustments */
        @media (max-width: 768px) {
            h2 {
                font-size: 1.8em;
            }
            form {
                padding: 25px;
            }
            form input[type="text"],
            form input[type="number"],
            form input[type="submit"] {
                padding: 12px;
            }
            table thead th,
            table tbody td {
                padding: 10px 12px;
                font-size: 0.9em;
            }
            table img {
                max-width: 70px;
            }
            .action-links a {
                padding: 6px 10px;
                font-size: 0.8em;
                margin-right: 5px;
            }
        }
        @media (max-width: 480px) {
            body {
                padding: 10px;
            }
            h2 {
                font-size: 1.5em;
            }
            form {
                padding: 20px;
            }
            input[type="text"],
            input[type="number"],
            input[type="submit"] {
                font-size: 0.9em;
            }
            .table-container {
                border-radius: 0; /* Remove border-radius on very small screens for full width appearance */
                box-shadow: none;
            }
            table {
                font-size: 0.8em;
            }
            table thead th,
            table tbody td {
                padding: 8px 10px;
            }
            table img {
                max-width: 60px;
            }
            .action-links {
                display: flex;
                flex-direction: column; /* Stack buttons vertically */
                align-items: flex-start;
            }
            .action-links a {
                width: calc(100% - 10px); /* Adjust width for stacked buttons */
                margin-bottom: 5px;
                margin-right: 0;
                text-align: center;
            }
        }
    </style>
</head>
<body>
    <?php
    // Tampilkan pesan sukses atau error jika ada
    if (isset($_SESSION['success_message'])) {
        echo '<div class="message success">' . $_SESSION['success_message'] . '</div>';
        unset($_SESSION['success_message']); // Hapus pesan setelah ditampilkan
    }
    if (isset($_SESSION['error_message'])) {
        echo '<div class="message error">' . $_SESSION['error_message'] . '</div>';
        unset($_SESSION['error_message']); // Hapus pesan setelah ditampilkan
    }
    ?>

    <h2>Tambah Buku Baru</h2>
    <div class="form-container">
        <form action="" method="post">
            <input type="text" name="kode_buku" placeholder="Kode Buku" required>
            <input type="number" name="no_buku" placeholder="No Buku" required>
            <input type="text" name="judul_buku" placeholder="Judul Buku" required>
            <input type="text" name="tahun_terbit" placeholder="Tahun Terbit (contoh: 2023)" pattern="\d{4}" title="Masukkan 4 digit tahun (contoh: 2023)" required>
            <input type="text" name="penulis" placeholder="Penulis" required>
            <input type="text" name="penerbit" placeholder="Penerbit" required>
            <input type="number" name="jumlah_halaman" placeholder="Jumlah Halaman" required>
            <input type="number" name="harga" placeholder="Harga" required>
            <input type="text" name="gambar_buku" placeholder="URL Gambar Buku" required>
            <input type="submit" name="tambah" value="Tambah Buku">
        </form>
    </div>

    <hr>

    <h2>Daftar Buku</h2>
    <div class="table-container">
        <table>
            <thead>
                <tr>
                    <th>KODE BUKU</th>
                    <th>NO BUKU</th>
                    <th>JUDUL BUKU</th>
                    <th>TAHUN TERBIT</th>
                    <th>PENULIS</th>
                    <th>PENERBIT</th>
                    <th>JUMLAH HALAMAN</th>
                    <th>HARGA</th>
                    <th>GAMBAR</th>
                    <th>Aksi</th>
                </tr>
            </thead>
            <tbody>
                <?php
                $sql = mysqli_query($koneksi, "SELECT * FROM buku ORDER BY no_buku ASC");
                if (mysqli_num_rows($sql) > 0) {
                    while ($data = mysqli_fetch_array($sql)) {
                ?>
                        <tr>
                            <td><?php echo htmlspecialchars($data['kode_buku']); ?></td>
                            <td><?php echo htmlspecialchars($data['no_buku']); ?></td>
                            <td><?php echo htmlspecialchars($data['judul_buku']); ?></td>
                            <td><?php echo htmlspecialchars($data['tahun_terbit']); ?></td>
                            <td><?php echo htmlspecialchars($data['penulis']); ?></td>
                            <td><?php echo htmlspecialchars($data['penerbit']); ?></td>
                            <td><?php echo htmlspecialchars($data['jumlah_halaman']); ?></td>
                            <td>Rp <?php echo number_format(htmlspecialchars($data['harga']), 0, ',', '.'); ?></td>
                            <td><img src="<?php echo htmlspecialchars($data['gambar_buku']); ?>" alt="cover"></td>
                            <td class="action-links">
                                <a href="edit.php?id=<?php echo htmlspecialchars($data['no_buku']); ?>" class="edit-btn">Edit</a>
                                <a href="?action=delete&id=<?php echo htmlspecialchars($data['no_buku']); ?>" class="delete-btn" onclick="return confirm('Apakah Anda yakin ingin menghapus buku ini?');">HAPUS</a>
                            </td>
                        </tr>
                <?php
                    }
                } else {
                    // Menggunakan kelas 'no-records' untuk styling pesan
                    echo "<tr><td colspan='10' class='no-records'>Belum ada data buku.</td></tr>";
                }

                mysqli_close($koneksi);
                ?>
            </tbody>
        </table>
    </div>
</body>
</html>